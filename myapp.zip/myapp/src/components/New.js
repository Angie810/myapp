import React from 'react'

function New(){
    return(
        
        <div>
            <p>I am footer</p>
        </div>
    )
}
export default New;