import React from 'react'
import '../footer.css';

function Footer(){
    return(
        
        <div className="footer">
            <p>Mobile: 072-316 55 76</p>
            <p>Email: xiaotong.huang810@outlook.com</p>
        </div>
    )
}
export default Footer;